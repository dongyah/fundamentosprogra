#Delivery de sushi

import time, os
os.system("cls")

#menu de sushi
valor_roll1 = 4500
valor_roll2 = 5000
valor_roll3 = 5200
valor_roll4 = 4800

nombre_roll1 = "Pikachu Roll"
nombre_roll2 = "Otaku Roll"
nombre_roll3 = "Pulpo Roll"
nombre_roll4 = "Anguila Eléctrica Roll"

#descuento
codigo_actual = "soyotaku"
descuento_x_codigo = 0.1 #10%

linea ="******************************"

cantidad_de_pedidos = 0
monto_total_vendido = 0
total_roll1 = 0
total_roll2 = 0
total_roll3 = 0
total_roll4 = 0
nombre_producto_mas_popular=""
total_producto_mas_popular=0

while True:

    #cada nuevo pedido
    cantidad = 0
    subtotal = 0
    total = 0
    descuento = 0
    cant_roll1 = 0
    cant_roll2 = 0
    cant_roll3 = 0
    cant_roll4 = 0

    while True:

        print("Bienvenido a Otaku Sushirolls")
        print("\tMenu")
        print(f"1. {nombre_roll1} ${valor_roll1} ")
        print(f"2. {nombre_roll2} ${valor_roll2} ")
        print(f"3. {nombre_roll3} ${valor_roll3} ")
        print(f"4. {nombre_roll4} ${valor_roll4} ")
        print("5. Salir")
        
        try:
            opcion = int(input("Seleccione el sushi que desea agregar a su pedido\n"))
        except:
            opcion = 0
        # end try
        if opcion < 1 or opcion > 5 :
            print("Opcion no valida, por favor seleccione del 1 al 5")
        elif opcion==1:
            print(f"{nombre_roll1} ha sido agregado a su pedido")
            cant_roll1 = cant_roll1 + 1
            cantidad = cantidad + 1
            subtotal = subtotal + valor_roll1
            print("Subtotal:",subtotal)
        elif opcion==2:
            print(f"{nombre_roll2} ha sido agregado a su pedido")
            cant_roll2 = cant_roll2 + 1
            cantidad = cantidad + 1
            subtotal = subtotal + valor_roll2
            print("Subtotal:",subtotal)
        elif opcion==3:
            print(f"{nombre_roll3} ha sido agregado a su pedido")
            cant_roll3 = cant_roll3 + 1
            cantidad = cantidad + 1
            subtotal = subtotal + valor_roll3
            print("Subtotal:",subtotal)
        elif opcion==4:
            print(f"{nombre_roll4} ha sido agregado a su pedido")
            cant_roll4 = cant_roll4 + 1
            cantidad = cantidad + 1
            subtotal = subtotal + valor_roll4
            print("Subtotal:",subtotal)
        else : # opcion==5:

            codigo_descto = input("ingrese codigo de descuento : ")
            if codigo_descto == codigo_actual :
                descuento = descuento_x_codigo
            else :
                descuento = 0
            #end if
            monto_descontado = int(round(subtotal * descuento,0))
            total = subtotal - monto_descontado

            print(linea)
            print(f'TOTAL PRODUCTOS : { cantidad }') 
            print(linea)
            print (f"{nombre_roll1} : {cant_roll1}")
            print (f"{nombre_roll2} : {cant_roll2}")
            print (f"{nombre_roll3} : {cant_roll3}")
            print (f"{nombre_roll4} : {cant_roll4}")
            print(linea)
            print(f"Subtotal : ${subtotal}")
            print(f"Descuento por código : ${monto_descontado}")
            print(f"Total : ${total}")
            print(linea)
            print("Gracias por visitarnos")
            print(linea)

            cantidad_de_pedidos = cantidad_de_pedidos + 1
            monto_total_vendido = monto_total_vendido +  total 
            total_roll1 = total_roll1 + cant_roll1
            total_roll2 = total_roll2 + cant_roll2
            total_roll3 = total_roll3 + cant_roll3
            total_roll4 = total_roll4 + cant_roll4

            break
        #end if
        print()

    #end while, fin de un pedido

    try:
        continuar = int(input("Desea realizar otro pedido?\n1.- Si (opcion por defecto)\n2.- No (salir del programa)\n> "))
    except:
        continuar = 1
    #end try
    
    if continuar != 1 :
        break
    #end if

#end while      

total_producto_mas_popular = total_roll1
nombre_producto_mas_popular=nombre_roll1

if total_roll2 > total_producto_mas_popular :
    total_producto_mas_popular = total_roll2
    nombre_producto_mas_popular=nombre_roll2
#end if

if total_roll3 > total_producto_mas_popular :
    total_producto_mas_popular = total_roll3
    nombre_producto_mas_popular=nombre_roll3
#end if

if total_roll4 > total_producto_mas_popular :
    total_producto_mas_popular = total_roll4
    nombre_producto_mas_popular=nombre_roll4
#end if

print("\nResumen")     
print(f"Pedidos Realizados : {cantidad_de_pedidos}")
print(f"Total Vendido      : $ {monto_total_vendido}")
print(f"Rollo más popular  : {nombre_producto_mas_popular} ({total_producto_mas_popular})")

print("\nSayonara!")        

